
def calculate_pnl(current_valuation: float, position: int, cash_invested: float):
	return cash_invested + (current_valuation * position)
